import { ext } from './compat.js';
// Общие константы и функции для фона, popup и настроек.

export const HOST_NAME = 'com.vlessbridge.host';

// Откуда скачивать помощник: ветка downloads репозитория на GitHub (её обновляет CI).
export const REPO_URL = 'https://github.com/maxhoney920/SafeBridge';
export const DOWNLOADS_PAGE = REPO_URL + '/tree/downloads';
export const INSTALL_DOC = REPO_URL + '#установка';
export const DOWNLOAD_BASE = REPO_URL + '/raw/downloads/';

// Все сборки помощника — для страницы установки.
export const HELPER_FILES = [
  { os: 'windows', name: 'Windows', variants: [
    { arch: 'amd64', label: 'Обычный компьютер (Intel / AMD)', file: 'safebridge-windows-amd64.exe' },
    { arch: 'arm64', label: 'ARM (Snapdragon, Surface Pro X)', file: 'safebridge-windows-arm64.exe' }] },
  { os: 'darwin', name: 'macOS', variants: [
    { arch: 'arm64', label: 'Apple Silicon (M1–M4)', file: 'safebridge-macos-arm64.zip' },
    { arch: 'amd64', label: 'Intel', file: 'safebridge-macos-amd64.zip' }] },
  { os: 'linux', name: 'Linux', variants: [
    { arch: 'amd64', label: 'x86-64', file: 'safebridge-linux-amd64' },
    { arch: 'arm64', label: 'ARM64 (aarch64)', file: 'safebridge-linux-arm64' }] },
];

// Помощник старше этой версии (первые сборки на sing-box) не умеет XHTTP и обновления.
export const MIN_HELPER = '0.3.0';

export function versionLess(a, b) {
  const pa = String(a || '0').replace(/^v/, '').split('.').map((x) => parseInt(x, 10) || 0);
  const pb = String(b || '0').replace(/^v/, '').split('.').map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) < (pb[i] || 0);
  }
  return false;
}

export const MADE_BY = { name: 'safe-internet', url: 'https://t.me/serv1897236bot' };

// «Сделано с любовью safe-internet ♥»
export function madeBy() {
  const a = el('a', { href: MADE_BY.url, target: '_blank', rel: 'noopener noreferrer', text: MADE_BY.name });
  return el('div', { class: 'made-by' }, 'Сделано с любовью ', a, ' ', el('span', { class: 'heart', 'aria-hidden': 'true', text: '♥' }));
}

// Аккаунт VPN-сервиса: вход через Google или Telegram, ключи подтягиваются сами.
// Сайт — личный кабинет бота; бот — где получить ключ и продлить подписку.
export const ACCOUNT = {
  name: 'safe-internet',
  site: 'https://tapp.internet-safe.online',
  bot: 'https://t.me/serv1897236bot',
  cabinet: 'https://tapp.internet-safe.online/login', // личный кабинет в браузере
};

// По этому файлу расширение в Chrome узнаёт о своей новой версии (Firefox обновляется сам).
// raw.githubusercontent.com отдаёт его с CORS, поэтому разрешения на сайт не нужны.
export const LATEST_URL = 'https://raw.githubusercontent.com/maxhoney920/SafeBridge/downloads/latest.json';
// Предупреждать о конце подписки за столько дней
export const EXPIRE_WARN_DAYS = 3;

// Чем закончился вход (ответ сайта в #error=…) — понятным языком.
export const ACCOUNT_ERRORS = {
  not_linked: 'Этот Google-аккаунт не привязан к боту. Откройте бота, получите ключ и нажмите «🔗 Привязать Google», затем войдите снова.',
  cancelled: 'Вход отменён.',
  invalid: 'Вход не удался или устарел. Попробуйте ещё раз.',
  banned: 'Доступ к аккаунту ограничен администратором.',
  google_not_configured: 'Вход через Google на сайте пока не настроен. Добавьте подписку вручную — ссылку можно взять в боте.',
};

// Срок действия подписки в секундах: из аккаунта или из заголовка подписки.
export const subExpire = (sub) => sub.expireAt || sub.info?.expire || 0;

// Подписки, которые скоро закончатся (или уже закончились), — для предупреждения.
export function expiringSubs(st, now = Date.now()) {
  return st.subs.map((s) => ({ sub: s, left: subExpire(s) * 1000 - now }))
    .filter((x) => x.sub.servers?.length && subExpire(x.sub) > 0 && x.left < EXPIRE_WARN_DAYS * 86400e3)
    .sort((a, b) => a.left - b.left);
}

export function fmtLeft(ms) {
  if (ms <= 0) return 'закончилась';
  const d = Math.round(ms / 86400e3);
  if (ms >= 86400e3) return `закончится через ${d} ${plural(d, 'день', 'дня', 'дней')}`;
  const h = Math.max(1, Math.floor(ms / 3600e3));
  return `закончится через ${h} ${plural(h, 'час', 'часа', 'часов')}`;
}

export const INSTALL_CMD = `curl -fsSL ${DOWNLOAD_BASE}install.sh | sh`;

// Шаги установки для каждой системы.
export function installSteps(os, file) {
  return {
    windows: [
      'Откройте скачанный файл.',
      'Если Windows покажет «Система Windows защитила ваш компьютер», нажмите «Подробнее», затем «Выполнить в любом случае».',
      'Дождитесь слова «Готово» в окне и нажмите Enter.',
      'Вернитесь в окно расширения и нажмите «Проверить».',
    ],
    darwin: [
      'Откройте скачанный архив двойным щелчком — рядом появится файл safebridge.',
      'Откройте safebridge двойным щелчком. macOS скажет, что не может проверить разработчика, — нажмите «Готово».',
      'Откройте Системные настройки → «Конфиденциальность и безопасность», внизу нажмите «Всё равно открыть» и подтвердите паролем.',
      'Дождитесь слова «Готово» в окне Терминала, вернитесь в окно расширения и нажмите «Проверить».',
    ],
    linux: [
      'Откройте терминал в папке загрузок.',
      `Выполните: chmod +x ${file || 'safebridge-linux-*'} && ./${file || 'safebridge-linux-*'}`,
      'Дождитесь слова «Готово», вернитесь в окно расширения и нажмите «Проверить».',
    ],
  }[os] || [];
}

// Файл помощника для платформы браузера (ext.runtime.getPlatformInfo).
export function helperDownload(p) {
  const arch = p.arch === 'arm64' || p.arch === 'arm' ? 'arm64' : 'amd64';
  const os = { win: 'windows', mac: 'darwin', linux: 'linux' }[p.os];
  const group = HELPER_FILES.find((g) => g.os === os);
  if (!group) return null;
  const v = group.variants.find((x) => x.arch === arch) || group.variants[0];
  return { os, arch: v.arch, name: group.name, file: v.file, url: DOWNLOAD_BASE + v.file };
}

export const DEFAULTS = {
  subs: [],            // [{id, url, name, ua, servers, info, updatedAt, error, account, mirror, expireAt}]
  selected: '',        // id выбранного сервера
  enabled: false,      // включён ли прокси в браузере
  mode: 'all',         // all | include | exclude
  include: [],         // домены для режима «только эти сайты»
  exclude: [],         // домены для режима «все, кроме этих»
  intervalMin: 120,    // автообновление подписок
  pingUrl: 'https://www.gstatic.com/generate_204',
  webrtc: true,        // защищать от утечки IP через WebRTC в режиме «все сайты»
  killSwitch: true,    // если VPN включён, но соединения нет — не пускать сайты напрямую
  port: 0,             // предпочтительный локальный порт (0 — любой свободный)
  autoCore: true,      // обновлять ядро Xray автоматически
  updates: null,       // результат последней проверки обновлений
  account: null,       // вход в ACCOUNT: {token, email, name, at, syncedAt, keys, renewUrl, expired, error}
  accountError: '',    // чем закончилась последняя попытка входа (not_linked, cancelled…)
  accountSite: '',     // другой адрес сайта аккаунта (только для проверки)
};

export async function load() {
  const st = await ext.storage.local.get(Object.keys(DEFAULTS));
  return { ...DEFAULTS, ...st };
}

export function save(patch) {
  return ext.storage.local.set(patch);
}

export function allServers(st) {
  const out = [];
  for (const sub of st.subs) for (const s of sub.servers || []) out.push({ ...s, subId: sub.id });
  return out;
}

// Принимает домен, адрес страницы, маску *.example.com или доменную зону (.ru, рф),
// возвращает домен в punycode. Пустая строка — не похоже на адрес сайта.
export function normalizeDomain(input) {
  let s = String(input || '').trim().toLowerCase();
  if (!s) return '';
  s = s.replace(/^\*\./, '').replace(/^\./, '');
  if (/^[a-z]{2,24}$/.test(s) || /^xn--[a-z0-9-]+$/.test(s)) return s; // зона: ru, com, xn--p1ai
  if (/^[^\x00-\x7f]+$/.test(s)) {
    try { return new URL('http://a.' + s).hostname.slice(2); } catch { return ''; } // зона «рф»
  }
  try {
    const u = new URL(/^[a-z][a-z0-9+.-]*:\/\//.test(s) ? s : 'http://' + s);
    s = u.hostname;
  } catch {
    return '';
  }
  s = s.replace(/\.$/, '');
  if (!/^[a-z0-9.-]+$/.test(s) && !/^\[[0-9a-f:]+\]$/.test(s)) return '';
  return s.includes('.') || s.startsWith('[') ? s : '';
}

// Домен сайта без поддоменов: music.youtube.com → youtube.com, www.bbc.co.uk → bbc.co.uk.
const SECOND_LEVEL = new Set(['co', 'com', 'net', 'org', 'gov', 'edu', 'ac', 'or', 'ne', 'go', 'msk', 'spb']);
export function siteDomain(host) {
  const parts = host.toLowerCase().replace(/\.$/, '').split('.');
  if (parts.length <= 2 || /^\d+$/.test(parts[parts.length - 1])) return parts.join('.');
  const n = parts.length;
  const take = SECOND_LEVEL.has(parts[n - 2]) && parts[n - 1].length === 2 ? 3 : 2;
  return parts.slice(-take).join('.');
}

export function domainMatches(host, list) {
  host = host.toLowerCase();
  return list.find((d) => host === d || host.endsWith('.' + d)) || null;
}

// PAC-скрипт: решение «через прокси или напрямую» по домену.
// tag меняется при смене сервера: Chrome видит новую конфигурацию прокси и закрывает
// старые соединения, иначе открытые сайты ещё какое-то время шли бы через прежний сервер.
export function buildPac({ mode, include, exclude }, port, tag = '') {
  const list = mode === 'include' ? include : mode === 'exclude' ? exclude : [];
  return `// server: ${String(tag).replace(/[^\w-]/g, '')}
var P = "SOCKS5 127.0.0.1:${port}";
var M = ${JSON.stringify(mode)};
var D = ${JSON.stringify(list)};
function inList(h) {
  for (var i = 0; i < D.length; i++) {
    var d = D[i];
    if (h === d || (h.length > d.length && h.substring(h.length - d.length - 1) === "." + d)) return true;
  }
  return false;
}
function FindProxyForURL(url, host) {
  host = host.toLowerCase();
  if (isPlainHostName(host) || host === "localhost" || host === "[::1]" || /\\.local$/.test(host) ||
      /^(127|10)\\./.test(host) || /^192\\.168\\./.test(host) || /^172\\.(1[6-9]|2\\d|3[01])\\./.test(host) ||
      /^169\\.254\\./.test(host)) return "DIRECT";
  if (M === "include") return inList(host) ? P : "DIRECT";
  if (M === "exclude") return inList(host) ? "DIRECT" : P;
  return P;
}`;
}

// Готовые наборы для списка «Через VPN».
export const PRESETS_VPN = [
  { name: 'YouTube', domains: ['youtube.com', 'youtu.be', 'googlevideo.com', 'ytimg.com', 'ggpht.com', 'youtube-nocookie.com', 'youtubei.googleapis.com', 'youtube.googleapis.com', 'jnn-pa.googleapis.com', 'youtubekids.com', 'yt.be'] },
  { name: 'Instagram', domains: ['instagram.com', 'cdninstagram.com', 'fbcdn.net', 'ig.me'] },
  { name: 'Facebook', domains: ['facebook.com', 'fb.com', 'fbcdn.net', 'messenger.com', 'facebook.net', 'fbsbx.com'] },
  { name: 'X (Twitter)', domains: ['x.com', 'twitter.com', 'twimg.com', 't.co'] },
  { name: 'Discord', domains: ['discord.com', 'discord.gg', 'discordapp.com', 'discordapp.net', 'discord.media', 'discordcdn.com'] },
  { name: 'ChatGPT', domains: ['chatgpt.com', 'openai.com', 'oaistatic.com', 'oaiusercontent.com', 'sora.com'] },
  { name: 'Claude', domains: ['claude.ai', 'anthropic.com', 'claudeusercontent.com', 'claude.com'] },
  // Gemini, AI Studio, NotebookLM и другие сервисы Google AI. Страница открывается с gemini.google.com,
  // а сами ответы идут через служебные адреса *-pa.googleapis.com и *.clients6.google.com:
  // без них Google видит настоящий адрес и пишет, что сервис в вашей стране недоступен.
  // Список сверен с v2fly/domain-list-community (google-deepmind) и itdoginfo/allow-domains.
  { name: 'Gemini', main: ['gemini.google.com', 'aistudio.google.com', 'gemini.google', 'notebooklm.google.com', 'notebooklm.google', 'labs.google', 'ai.google.dev'],
    domains: ['gemini.google.com', 'aistudio.google.com', 'gemini.google', 'bard.google.com', 'gemini.gstatic.com',
      'generativelanguage.googleapis.com', 'robinfrontend-pa.googleapis.com', 'proactivebackend-pa.googleapis.com',
      'geller-pa.googleapis.com', 'aisandbox-pa.googleapis.com', 'aida.googleapis.com', 'speechs3proto2-pa.googleapis.com',
      'clients6.google.com', 'makersuite.google.com', 'ai.google.dev', 'ai.studio', 'generativeai.google',
      'notebooklm.google.com', 'notebooklm.google', 'notebooklm-pa.googleapis.com', 'notebooklm.googleapis.com',
      'labs.google', 'labs.google.com', 'jules.google', 'jules.google.com', 'deepmind.google', 'deepmind.com'] },
  { name: 'TikTok', domains: ['tiktok.com', 'tiktokcdn.com', 'tiktokv.com', 'ttwstatic.com', 'byteoversea.com', 'ibytedtos.com', 'tiktokcdn-us.com', 'tiktokcdn-eu.com'] },
  { name: 'Twitch', domains: ['twitch.tv', 'ttvnw.net', 'jtvnw.net', 'twitchcdn.net', 'twitchsvc.net', 'ext-twitch.tv'] },
  { name: 'Spotify', domains: ['spotify.com', 'scdn.co', 'spotifycdn.com', 'spotilocal.com', 'pscdn.co'] },
  { name: 'Netflix', domains: ['netflix.com', 'nflxvideo.net', 'nflximg.net', 'nflxext.com', 'nflxso.net'] },
  { name: 'LinkedIn', domains: ['linkedin.com', 'licdn.com'] },
  { name: 'Reddit', domains: ['reddit.com', 'redd.it', 'redditmedia.com', 'redditstatic.com'] },
  { name: 'Medium', domains: ['medium.com', 'miro.medium.com'] },
  { name: 'Telegram Web', domains: ['telegram.org', 't.me', 'telegram.me', 'telesco.pe'] },
];

// Готовые наборы для списка «Без VPN».
export const PRESETS_DIRECT = [
  { name: 'Все сайты .ru, .рф, .su', domains: ['ru', 'xn--p1ai', 'su'] },
  { name: 'Госуслуги и налоги', domains: ['gosuslugi.ru', 'nalog.gov.ru', 'mos.ru', 'esia.gosuslugi.ru'] },
  { name: 'Банки', domains: ['sberbank.ru', 'tbank.ru', 'tinkoff.ru', 'vtb.ru', 'alfabank.ru', 'gazprombank.ru', 'raiffeisen.ru'] },
  { name: 'Маркетплейсы', domains: ['ozon.ru', 'wildberries.ru', 'wb.ru', 'avito.ru', 'market.yandex.ru'] },
  { name: 'Яндекс', service: true, domains: ['yandex.ru', 'ya.ru', 'yandex.net', 'yastatic.net', 'yandex.com'] },
  { name: 'VK и Mail.ru', service: true, domains: ['vk.com', 'vk.ru', 'userapi.com', 'vkuser.net', 'mail.ru', 'ok.ru'] },
];

export const PRESETS = PRESETS_VPN;

// Набор, в который входит сайт. Возвращает набор только для «больших» сайтов,
// а не для вспомогательных: на ggpht.com набор YouTube не предлагаем, а на youtube.com — да.
export function presetFor(host, list) {
  // в «Без VPN» подставляем только наборы одного сервиса, а не «все банки» или зону .ru
  const sets = list === 'exclude' ? PRESETS_DIRECT.filter((p) => p.service) : PRESETS_VPN;
  const h = host.toLowerCase();
  return sets.find((p) => {
    // основные адреса набора: p.main, а если его нет — первые два домена
    const m = domainMatches(h, p.main || p.domains.slice(0, 2));
    return !!m;
  }) || null;
}

// Наборы со временем пополняются. Если набор уже стоит в списке (есть его основной домен
// и ещё хотя бы два его адреса), добавляем недостающие адреса из новой версии набора.
export function upgradePresets(list, sets = PRESETS_VPN) {
  const have = new Set(list);
  const add = [];
  for (const p of sets) {
    const mains = p.main || p.domains.slice(0, 2);
    const present = p.domains.filter((d) => have.has(d));
    if (!mains.some((d) => have.has(d)) || present.length < 3) continue;
    for (const d of p.domains) if (!have.has(d)) { have.add(d); add.push(d); }
  }
  return add;
}

// Домены, которые страница загружает со сторонних адресов (видео, картинки, API).
// Счётчики и рекламу не предлагаем: им не нужен VPN.
const NOISE = ['google-analytics.com', 'googletagmanager.com', 'doubleclick.net', 'googlesyndication.com',
  'googleadservices.com', 'hotjar.com', 'sentry.io', 'cloudflareinsights.com', 'clarity.ms',
  'scorecardresearch.com', 'criteo.com', 'yandex.ru', 'yandex.net', 'mail.ru'];
// Общие площадки: на них живут тысячи чужих сайтов, поэтому предлагаем точный адрес,
// а не всю площадку (иначе google.com увёл бы через VPN весь Google).
const SHARED = ['google.com', 'googleapis.com', 'gstatic.com', 'amazonaws.com', 'cloudfront.net',
  'akamaized.net', 'akamaihd.net', 'fastly.net', 'azureedge.net', 'cloudflare.com', 'jsdelivr.net',
  'githubusercontent.com', 'appspot.com', 'firebaseio.com', 'windows.net'];

export function relatedDomains(hosts, tabHost, list) {
  const own = siteDomain(tabHost);
  const out = new Map(); // домен -> сколько адресов
  for (const raw of hosts) {
    const h = String(raw).toLowerCase().replace(/\.$/, '');
    if (!h.includes('.') || /^[\d.]+$/.test(h) || h.includes(':')) continue;
    if (domainMatches(h, list)) continue; // уже идёт через VPN
    const base = siteDomain(h);
    if (base === own || NOISE.includes(base)) continue;
    const d = SHARED.includes(base) ? h : base;
    out.set(d, (out.get(d) || 0) + 1);
  }
  // не больше 30: страница может нарочно загрузить что угодно, чтобы подсунуть длинный список
  return [...out.entries()].sort((a, b) => b[1] - a[1]).map(([d]) => d).slice(0, 30);
}

// Режимы и списки — одни и те же слова в окне расширения и в настройках.
export const MODES = {
  all: { label: 'Все сайты', hint: 'Все сайты открываются через VPN.' },
  include: { label: 'Только список', hint: 'Через VPN открываются только сайты из списка «Через VPN». Остальные — напрямую, как без расширения.' },
  exclude: { label: 'Исключения', hint: 'Через VPN открываются все сайты, кроме исключений из списка «Без VPN».' },
};
export const LIST_NAMES = { include: '«Через VPN»', exclude: '«Без VPN»' };

// ---------- форматирование ----------

export function fmtBytes(n) {
  if (!n) return '0 ГБ';
  const gb = n / 1024 ** 3;
  if (gb >= 100) return Math.round(gb) + ' ГБ';
  if (gb >= 1) return gb.toFixed(1).replace('.', ',') + ' ГБ';
  return Math.max(1, Math.round(n / 1024 ** 2)) + ' МБ';
}

export function fmtAgo(ts) {
  if (!ts) return 'ещё не обновлялась';
  const m = Math.round((Date.now() - ts) / 60000);
  if (m < 1) return 'обновлена только что';
  if (m < 60) return `обновлена ${m} мин назад`;
  const h = Math.round(m / 60);
  if (h < 24) return `обновлена ${h} ч назад`;
  return `обновлена ${new Date(ts).toLocaleDateString('ru-RU')}`;
}

export function fmtDate(sec) {
  return new Date(sec * 1000).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' });
}

export function protoLabel(s) {
  const p = { vless: 'VLESS', vmess: 'VMess', trojan: 'Trojan', shadowsocks: 'SS', hysteria2: 'Hysteria2' }[s.protocol] || s.protocol;
  const extra = [];
  if (s.security === 'reality') extra.push('Reality');
  else if (s.security === 'tls' && s.protocol !== 'trojan' && s.protocol !== 'hysteria2') extra.push('TLS');
  const tr = { xhttp: 'XHTTP', ws: 'WS', grpc: 'gRPC', httpupgrade: 'HTTPUpgrade', kcp: 'mKCP' }[s.transport];
  if (tr) extra.push(tr);
  return [p, ...extra].join(' + ');
}

export function send(type, data = {}) {
  return ext.runtime.sendMessage({ type, ...data });
}

export function el(tag, attrs = {}, ...children) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k === 'text') e.textContent = v;
    else e.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat(Infinity)) if (c != null && c !== false) e.append(c.nodeType ? c : String(c));
  return e;
}

export function plural(n, one, few, many) {
  const a = n % 10, b = n % 100;
  if (a === 1 && b !== 11) return one;
  if (a >= 2 && a <= 4 && (b < 12 || b > 14)) return few;
  return many;
}
